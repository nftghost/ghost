import IMG from "../img/spinner.gif"

export const LOADING_ASSET = {"image_url": IMG, "name": "Loading Offer", "permalink": "https://opensea.io/assets", "description": "Loading Asset details"};

export const OPENSEA_ASSETS = "https://rinkeby-api.opensea.io/api/v1/assets/";

export const OPENSEA_SINGLE_ASSET = "https://rinkeby-api.opensea.io/api/v1/asset/";

export const API_KEY = "4e9ca01b6f0c403d9c5110b9c89b177a";
