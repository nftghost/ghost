export const REQUEST_STATUS = ["Pending", "Active", "Cancelled", "Ended", "Defaulted"];

export const LENDING_CONTRACT_ADDRESS = '0x44Cd391C03838B97e9012259A21dF65f55BC7Edd';
