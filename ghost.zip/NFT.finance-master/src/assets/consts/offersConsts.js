export const OFFER_STATUS = ["Pending", "Active", "Cancelled", "Ended"];

export const LEASING_CONTRACT_ADDRESS = '0xf35515FeBFFe6646Efe262a44AB1888E8B90DD8A';

export const RINKEBY_NETWORK_VERSION = 4;
